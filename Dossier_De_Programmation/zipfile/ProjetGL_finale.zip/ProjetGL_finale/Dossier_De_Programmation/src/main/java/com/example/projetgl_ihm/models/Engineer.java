package com.example.projetgl_ihm.models;

public class Engineer extends Employee {
    public Engineer(String username, String password) {
        super(username, password, "engineer");
    }
}