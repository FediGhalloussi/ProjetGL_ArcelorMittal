package com.example.projetgl_ihm.models;

public class Worker extends Employee {
    public Worker(String username, String password) {
        super(username, password, "worker");
    }
}
